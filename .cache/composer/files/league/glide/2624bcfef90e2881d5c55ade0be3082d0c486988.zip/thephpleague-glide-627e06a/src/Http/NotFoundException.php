<?php

namespace League\Glide\Http;

use Exception;

class NotFoundException extends Exception
{
}
