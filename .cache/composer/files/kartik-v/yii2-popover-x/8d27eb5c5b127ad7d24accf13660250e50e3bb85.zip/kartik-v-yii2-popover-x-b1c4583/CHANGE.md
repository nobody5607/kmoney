version 1.3.0
=============
**Date:** 25-Nov-2014

- (enh #5): Enhance widget to use updated plugin registration from Krajee base

version 1.2.0
=============
**Date:** 10-Nov-2014

- Set dependency on Krajee base components
- Set release to stable

version 1.1.0
=============
**Date:** 2014-10-24

- Enhancements for release v1.1.0 of bootstrap-popover-x plugin.
- enh #2: Allow widget to be used as a popover in NavBar.
- enh #3: Add `content` property to render the widget directly without begin and end methods.
- enh #4: Add `arrowOptions` property to configure HTML attributes for arrow.


version 1.0.0
=============
**Date:** 2014-07-15
- Initial release
- PSR4 alias change
