<?php
return [
    'Clear field' => 'Alanı Temizle',
    'Select date' => 'Tarih Seç',
];
