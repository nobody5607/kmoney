<?php

return [
    'ERROR_CAN_NOT_UPLOAD_FILE' => 'O arquivo não pode ser carregado.',
];
