DomCrawler Component
====================

The DomCrawler component eases DOM navigation for HTML and XML documents.

Resources
---------

  * [Documentation](https://symfony.com/doc/current/components/dom_crawler.html)
  * [Contributing](https://symfony.com/doc/current/contributing/index.html)
  * [Report issues](https://github.com/symfony/symfony/issues) and
    [send Pull Requests](https://github.com/symfony/symfony/pulls)
    in the [main Symfony repository](https://github.com/symfony/symfony)
