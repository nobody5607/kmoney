<?php
namespace Codeception\Exception;

class Fail extends \PHPUnit\Framework\AssertionFailedError
{

}
