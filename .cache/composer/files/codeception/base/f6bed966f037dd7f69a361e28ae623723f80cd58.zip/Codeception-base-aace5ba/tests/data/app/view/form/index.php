<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Test submitting a form with a document-relative path for action</title>
</head>
<body>
    Link: <a href="example11">Doc-Relative Link</a>
    <form method="POST" action="example11">
        <input type="text" name="test" value="" />
        <input type="submit" name="submit" value="Submit" />
    </form>
</body>
</html>