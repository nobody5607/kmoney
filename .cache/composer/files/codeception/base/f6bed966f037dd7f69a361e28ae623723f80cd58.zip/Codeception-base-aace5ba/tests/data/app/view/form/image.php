<html>
<body>
<form action="/form/image" method="POST">
    <input type="hidden" name="text" value="val" />
    <input type="image" src="button.gif" alt="Submit" />
</form>
</body>
</html>