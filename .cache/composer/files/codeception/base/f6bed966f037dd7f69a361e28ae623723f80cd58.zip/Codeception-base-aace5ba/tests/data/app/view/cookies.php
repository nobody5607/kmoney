<html>
<body>
    <?php echo "<pre>" . print_r($_COOKIE, 1) . "</pre>";
    ?>
    <h1>Cookies.php View</h1>

</body>
</html>
