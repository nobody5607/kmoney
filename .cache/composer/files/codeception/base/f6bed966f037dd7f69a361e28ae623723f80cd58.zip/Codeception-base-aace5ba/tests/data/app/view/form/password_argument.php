<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head></head>
<body>
<form action="/form/password_argument" method="post">
    <input type="password" id="password" name="password">
    <button type="submit">Submit</button>
</form>
</body>
</html>
