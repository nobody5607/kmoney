<html>
<body>
<div>
    <button>The Button</button>
</div>
</body>
</html>