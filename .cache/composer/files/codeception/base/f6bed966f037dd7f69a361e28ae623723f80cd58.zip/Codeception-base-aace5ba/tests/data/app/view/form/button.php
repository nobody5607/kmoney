<html>
<body>
<form action="/form/button" method="POST">
    <input type="hidden" name="text" value="val" />
    <button type="submit" name="btn0">Submit</button>
</form>
</body>
</html>