<?php
return [
    'Maximum number of files exceeded' => '超过最大文件数量',
    'File type not allowed' => '不允许的文件类型',
    'File is too large' => '文件太大',
    'File is too small' => '文件太小'
];
