<?php
/**
 * Project yii2-file-kit.
 * Author: Eugene Terentev <eugene@terentev.net>
 */
return [
    'Maximum number of files exceeded' => 'Numero massimo di file superati',
    'File type not allowed' => 'Tipo di file non consentito',
    'File is too large' => 'Il file è troppo grande',
    'File is too small' => 'Il file è troppo piccolo'
];