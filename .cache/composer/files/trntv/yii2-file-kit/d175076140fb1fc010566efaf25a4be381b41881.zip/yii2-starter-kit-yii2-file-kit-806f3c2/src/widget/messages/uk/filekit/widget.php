<?php
/**
 * Project yii2-file-kit.
 * Author: Eugene Terentev <eugene@terentev.net>
 */
return [
    'Maximum number of files exceeded' => 'Досягнута максимальна кількість файлів',
    'File type not allowed' => 'Тип файлу не дозволений',
    'File is too large' => 'Файл завеликий',
    'File is too small' => 'Файл меньше мінімального розміру'
];
