<?php
/**
 * Project yii2-file-kit.
 * Author: Eugene Terentev <eugene@terentev.net>
 */
return [
    'Maximum number of files exceeded' => 'Taille maximale dépassée',
    'File type not allowed' => 'Type de fichier accepté',
    'File is too large' => 'Le fichier est trop grand',
    'File is too small' => 'Le fichier est trop petit'
];