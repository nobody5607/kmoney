<?php
return [
    'Maximum number of files exceeded' => 'Elérte a megengedett fájl darab számot',
    'File type not allowed' => 'Fájl típus nem megengedett',
    'File is too large' => 'Fájl túl nagy',
    'File is too small' => 'Fájl túl kicsi'
];
