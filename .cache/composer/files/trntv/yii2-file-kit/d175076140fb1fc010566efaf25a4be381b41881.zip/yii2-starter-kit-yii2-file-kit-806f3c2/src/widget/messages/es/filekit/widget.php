<?php
/**
 * Project yii2-file-kit.
 * Author: Eugene Terentev <eugene@terentev.net>
 */
return [
    'Maximum number of files exceeded' => 'Se ha superado el límite de archivos permitidos',
    'File type not allowed' => 'Formato de archivo no permitido',
    'File is too large' => 'Fichero demasiado grande',
    'File is too small' => 'Fichero demasiado pequeño'
];