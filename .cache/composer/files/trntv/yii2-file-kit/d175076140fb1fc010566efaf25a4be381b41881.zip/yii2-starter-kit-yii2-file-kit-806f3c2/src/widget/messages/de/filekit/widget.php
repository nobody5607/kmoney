<?php
/**
 * Project yii2-file-kit.
 * Author: Eugene Terentev <eugene@terentev.net>
 */
return [
    'Maximum number of files exceeded' => 'Maximale anzahl von dateien überschritten',
    'File type not allowed' => 'Dateityp nicht erlaubt',
    'File is too large' => 'Datei ist zu groß',
    'File is too small' => 'Datei ist zu klein'
];