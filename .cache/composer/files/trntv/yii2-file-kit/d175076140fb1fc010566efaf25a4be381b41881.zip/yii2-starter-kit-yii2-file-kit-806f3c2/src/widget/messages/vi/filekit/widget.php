<?php
return [
    'Maximum number of files exceeded' => 'Số lượng tối đa của tệp vượt quá',
    'File type not allowed' => 'Loại tệp không được phép',
    'File is too large' => 'Tập tin quá lớn',
    'File is too small' => 'Tập tin quá nhỏ'
];
